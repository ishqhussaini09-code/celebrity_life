import { useMemo, useReducer, useState } from 'react';
import {
  Activity, ArrowUpRight, BatteryMedium, Bell, BookOpen, BriefcaseBusiness,
  CalendarDays, Camera, Check, ChevronRight, CircleDollarSign, CircleUserRound,
  Clapperboard, Cloud, Clock3, Dumbbell, FileText, Film, Gamepad2, Globe2,
  HeartPulse, Home, Image, Laptop, LockKeyhole, Mail, MapPin, MessageCircle,
  Mic2, MonitorPlay, Moon, Newspaper, Package, Pencil, Phone, Play,
  Plus, Radio, Search, Settings2, Shirt, ShoppingBag, Signal, Sparkles, Star,
  TrendingUp, Tv, Upload, Users, Utensils, WalletCards, Wifi, WifiOff, X,
  Zap, type LucideIcon,
} from 'lucide-react';

type AppId =
  | 'wallet' | 'jobs' | 'mart' | 'viewtube' | 'reeltok' | 'starcast' | 'rent'
  | 'kitchen' | 'sleep' | 'skills' | 'social' | 'messages' | 'mail' | 'calendar'
  | 'maps' | 'camera' | 'gallery' | 'notes' | 'music' | 'stream' | 'health'
  | 'news' | 'contacts' | 'browser' | 'settings' | 'cloud' | 'files' | 'radio'
  | 'podcast' | 'studio' | 'analytics' | 'wardrobe' | 'photobooth' | 'fund'
  | 'city' | 'help';

type GameState = {
  day: number;
  cash: number;
  fame: number;
  energy: number;
  hunger: number;
  health: number;
  skill: { acting: number; editing: number; social: number };
  followers: { viewtube: number; reeltok: number };
  accounts: { viewtube: boolean; reeltok: boolean };
  inventory: string[];
  streak: number;
  lastAction: string;
};

const initialState: GameState = {
  day: 1, cash: 100, fame: 0, energy: 84, hunger: 88, health: 100,
  skill: { acting: 8, editing: 4, social: 6 },
  followers: { viewtube: 0, reeltok: 0 },
  accounts: { viewtube: false, reeltok: false },
  inventory: ['cracked phone', 'shared apartment'],
  streak: 0,
  lastAction: 'You woke up in a room that costs more than your whole life.',
};

type Action =
  | { type: 'advance' }
  | { type: 'work' }
  | { type: 'buy'; item: string; price: number }
  | { type: 'account'; platform: 'viewtube' | 'reeltok' }
  | { type: 'upload'; platform: 'viewtube' | 'reeltok'; followers: number; fame: number; cost: number; label: string }
  | { type: 'train'; skill: 'acting' | 'editing' | 'social'; cost: number }
  | { type: 'eat' };

function gameReducer(state: GameState, action: Action): GameState {
  switch (action.type) {
    case 'advance': {
      const day = state.day + 1;
      const weeklyRent = day % 7 === 0 ? 220 : 0;
      const tiredHealth = state.hunger <= 25 ? 8 : 0;
      return {
        ...state,
        day,
        cash: state.cash - weeklyRent,
        energy: Math.max(0, state.energy - 8),
        hunger: Math.max(0, state.hunger - 11),
        health: Math.max(0, state.health - tiredHealth),
        streak: state.streak + 1,
        lastAction: weeklyRent ? `Rent day. $${weeklyRent} disappeared before breakfast.` : 'Another day starts. The city is already asking for something.',
      };
    }
    case 'work':
      if (state.energy < 30) return { ...state, lastAction: 'You cannot finish a shift on an empty battery.' };
      return {
        ...state, cash: state.cash + 40, energy: Math.max(0, state.energy - 30),
        hunger: Math.max(0, state.hunger - 8), lastAction: 'Six hours for forty dollars. Your knees remember every minute.',
      };
    case 'buy':
      if (state.cash < action.price) return { ...state, lastAction: `You count the money twice. Still short $${action.price - state.cash}.` };
      if (state.inventory.includes(action.item)) return { ...state, lastAction: 'You already own that. Protect your cash.' };
      return { ...state, cash: state.cash - action.price, inventory: [...state.inventory, action.item], lastAction: `${action.item} is yours. Now make it pay rent.` };
    case 'account':
      return { ...state, accounts: { ...state.accounts, [action.platform]: true }, lastAction: `Your ${action.platform === 'viewtube' ? 'ViewTube' : 'ReelTok'} account is live. Zero followers is still an audience of zero.` };
    case 'upload':
      return {
        ...state, cash: state.cash - action.cost, energy: Math.max(0, state.energy - 10),
        fame: state.fame + action.fame, followers: { ...state.followers, [action.platform]: state.followers[action.platform] + action.followers },
        lastAction: action.label,
      };
    case 'train':
      if (state.energy < action.cost) return { ...state, lastAction: 'No energy for a lesson. The algorithm does not care.' };
      return { ...state, energy: Math.max(0, state.energy - action.cost), skill: { ...state.skill, [action.skill]: state.skill[action.skill] + 5 }, lastAction: `You trained ${action.skill}. The improvement is quiet, but real.` };
    case 'eat':
      if (state.cash < 8) return { ...state, lastAction: 'The vending machine rejects your card. Hunger keeps score.' };
      return { ...state, cash: state.cash - 8, hunger: Math.min(100, state.hunger + 28), health: Math.min(100, state.health + 2), lastAction: 'Hot food. Not glamorous. Suddenly you can think again.' };
    default: return state;
  }
}

type AppConfig = { id: AppId; name: string; subtitle: string; icon: LucideIcon; tint: string; kind?: 'locked' | 'preview' | 'functional' };

const apps: AppConfig[] = [
  { id: 'wallet', name: 'Wallet', subtitle: 'cash & survival', icon: WalletCards, tint: 'gold', kind: 'functional' },
  { id: 'jobs', name: 'JobBoard', subtitle: 'trade time for cash', icon: BriefcaseBusiness, tint: 'coral', kind: 'functional' },
  { id: 'mart', name: 'MegaMart', subtitle: 'tools for the climb', icon: ShoppingBag, tint: 'blue', kind: 'functional' },
  { id: 'viewtube', name: 'ViewTube', subtitle: 'upload / be ignored', icon: MonitorPlay, tint: 'red', kind: 'functional' },
  { id: 'reeltok', name: 'ReelTok', subtitle: 'short attention spans', icon: Film, tint: 'violet', kind: 'functional' },
  { id: 'starcast', name: 'StarCast', subtitle: 'auditions & agents', icon: Clapperboard, tint: 'gold', kind: 'locked' },
  { id: 'rent', name: 'Rent & Bills', subtitle: 'due day 07', icon: FileText, tint: 'coral', kind: 'preview' },
  { id: 'kitchen', name: 'Kitchen', subtitle: 'feed the machine', icon: Utensils, tint: 'orange', kind: 'functional' },
  { id: 'sleep', name: 'Sleep', subtitle: 'borrow from tomorrow', icon: Moon, tint: 'indigo', kind: 'functional' },
  { id: 'skills', name: 'Skill Lab', subtitle: 'small gains, daily', icon: Dumbbell, tint: 'mint', kind: 'functional' },
  { id: 'social', name: 'Social', subtitle: 'connections', icon: Users, tint: 'pink', kind: 'preview' },
  { id: 'messages', name: 'Messages', subtitle: 'seen at 2:14 AM', icon: MessageCircle, tint: 'green', kind: 'preview' },
  { id: 'mail', name: 'Mail', subtitle: 'no new miracles', icon: Mail, tint: 'blue', kind: 'preview' },
  { id: 'calendar', name: 'Calendar', subtitle: 'audition: maybe', icon: CalendarDays, tint: 'red', kind: 'preview' },
  { id: 'maps', name: 'Maps', subtitle: 'find the cheap route', icon: MapPin, tint: 'orange', kind: 'preview' },
  { id: 'camera', name: 'Camera', subtitle: 'cracked lens', icon: Camera, tint: 'slate', kind: 'preview' },
  { id: 'gallery', name: 'Gallery', subtitle: 'proof of life', icon: Image, tint: 'violet', kind: 'preview' },
  { id: 'notes', name: 'Notes', subtitle: 'lines worth keeping', icon: BookOpen, tint: 'yellow', kind: 'preview' },
  { id: 'music', name: 'Music', subtitle: 'background noise', icon: Radio, tint: 'pink', kind: 'preview' },
  { id: 'stream', name: 'Stream', subtitle: 'watch the winners', icon: Tv, tint: 'blue', kind: 'preview' },
  { id: 'health', name: 'Health', subtitle: 'the body keeps score', icon: HeartPulse, tint: 'green', kind: 'preview' },
  { id: 'news', name: 'News', subtitle: 'industry weather', icon: Newspaper, tint: 'coral', kind: 'preview' },
  { id: 'contacts', name: 'Contacts', subtitle: 'make them remember', icon: CircleUserRound, tint: 'gold', kind: 'preview' },
  { id: 'browser', name: 'Browser', subtitle: 'the whole machine', icon: Globe2, tint: 'blue', kind: 'preview' },
  { id: 'settings', name: 'Settings', subtitle: 'personal parameters', icon: Settings2, tint: 'slate', kind: 'preview' },
  { id: 'cloud', name: 'Cloud', subtitle: 'storage: 4.2 GB', icon: Cloud, tint: 'indigo', kind: 'preview' },
  { id: 'files', name: 'Files', subtitle: 'receipts & résumés', icon: Package, tint: 'orange', kind: 'preview' },
  { id: 'radio', name: 'Radio', subtitle: 'late-night company', icon: Mic2, tint: 'pink', kind: 'preview' },
  { id: 'podcast', name: 'Podcasts', subtitle: 'listen / learn', icon: Radio, tint: 'violet', kind: 'preview' },
  { id: 'studio', name: 'Studio', subtitle: 'editing suite', icon: Laptop, tint: 'mint', kind: 'preview' },
  { id: 'analytics', name: 'Analytics', subtitle: 'numbers do not lie', icon: TrendingUp, tint: 'gold', kind: 'preview' },
  { id: 'wardrobe', name: 'Wardrobe', subtitle: 'look expensive', icon: Shirt, tint: 'coral', kind: 'preview' },
  { id: 'photobooth', name: 'Photo Booth', subtitle: 'headshots pending', icon: CircleUserRound, tint: 'blue', kind: 'preview' },
  { id: 'fund', name: 'Creator Fund', subtitle: '$0.00 earned', icon: CircleDollarSign, tint: 'gold', kind: 'locked' },
  { id: 'city', name: 'City Guide', subtitle: 'where the rent is not', icon: Home, tint: 'green', kind: 'preview' },
  { id: 'help', name: 'Help', subtitle: 'read the fine print', icon: Bell, tint: 'slate', kind: 'preview' },
];

const money = (amount: number) => `$${Math.max(0, amount).toLocaleString('en-US')}`;
const clamp = (n: number) => Math.min(100, Math.max(0, n));

function Stat({ icon: Icon, label, value, color, suffix = '' }: { icon: LucideIcon; label: string; value: number | string; color: string; suffix?: string }) {
  return (
    <div className="min-w-0 flex-1 border-r border-white/[.08] px-2.5 last:border-0 sm:px-4" data-testid={`stat-${label.toLowerCase()}`}>
      <div className="mb-1 flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-[.15em] text-slate-500"><Icon size={12} style={{ color }} />{label}</div>
      <div className="font-mono text-[13px] font-bold tracking-tight text-[#f2ead9] sm:text-[15px]">{value}{suffix}</div>
    </div>
  );
}

function Modal({ title, eyebrow, onClose, children }: { title: string; eyebrow?: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-[#05070b]/75 p-0 backdrop-blur-sm sm:items-center sm:p-6" role="dialog" aria-modal="true">
      <div className="animate-launch max-h-[92dvh] w-full max-w-xl overflow-auto rounded-t-[1.6rem] border border-white/10 bg-[#121821] shadow-2xl sm:rounded-[1.6rem]">
        <div className="sticky top-0 z-10 flex items-start justify-between border-b border-white/[.07] bg-[#121821]/95 px-5 py-4 backdrop-blur sm:px-7">
          <div><div className="mb-1 font-mono text-[10px] uppercase tracking-[.22em] text-[#d8aa56]">{eyebrow || 'StarOS utility'}</div><h2 className="font-serif text-3xl leading-none text-[#f2ead9]">{title}</h2></div>
          <button data-testid="button-close-modal" onClick={onClose} className="rounded-full p-2 text-slate-500 transition hover:bg-white/10 hover:text-white"><X size={18} /></button>
        </div>
        <div className="p-5 sm:p-7">{children}</div>
      </div>
    </div>
  );
}

function Progress({ value, color }: { value: number; color: string }) {
  return <div className="h-1.5 overflow-hidden rounded-full bg-white/[.07]"><div className="h-full rounded-full transition-all duration-500" style={{ width: `${clamp(value)}%`, background: color }} /></div>;
}

function PrimaryButton({ children, onClick, disabled, testId, variant = 'gold' }: { children: React.ReactNode; onClick: () => void; disabled?: boolean; testId: string; variant?: 'gold' | 'dark' | 'coral' }) {
  return <button data-testid={testId} disabled={disabled} onClick={onClick} className={`flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 text-[12px] font-bold uppercase tracking-[.11em] transition active:scale-[.98] disabled:cursor-not-allowed disabled:opacity-35 ${variant === 'gold' ? 'bg-[#d8aa56] text-[#14151a] hover:bg-[#f0c56f]' : variant === 'coral' ? 'bg-[#bd5262] text-[#fff4ed] hover:bg-[#d26977]' : 'border border-white/10 bg-white/[.06] text-[#eee4d2] hover:bg-white/[.1]'}`}>{children}</button>;
}

function JobBoard({ state, dispatch, close }: { state: GameState; dispatch: React.Dispatch<Action>; close: () => void }) {
  const canWork = state.energy >= 30;
  return <Modal title="JobBoard" eyebrow="cashflow / day job" onClose={close}>
    <div className="mb-5 flex items-center justify-between rounded-xl border border-[#d8aa56]/20 bg-[#d8aa56]/[.06] p-4">
      <div><p className="text-sm font-semibold text-[#f0e8da]">Diner closing shift</p><p className="mt-1 text-xs text-slate-500">6 hours · tonight · no experience required</p></div>
      <span className="font-mono text-lg font-bold text-[#d8aa56]">+$40</span>
    </div>
    <div className="mb-5 grid grid-cols-3 gap-2 text-center">
      <div className="rounded-lg bg-white/[.04] p-3"><Clock3 className="mx-auto mb-1 text-slate-400" size={16} /><span className="font-mono text-xs text-slate-300">6 hrs</span></div>
      <div className="rounded-lg bg-white/[.04] p-3"><Zap className="mx-auto mb-1 text-[#e7b75d]" size={16} /><span className="font-mono text-xs text-slate-300">−30 energy</span></div>
      <div className="rounded-lg bg-white/[.04] p-3"><Utensils className="mx-auto mb-1 text-[#c77065]" size={16} /><span className="font-mono text-xs text-slate-300">−8 hunger</span></div>
    </div>
    <p className="mb-4 text-xs leading-relaxed text-slate-500">The manager will not ask why you were late. They will ask why you are not faster.</p>
    <PrimaryButton testId="button-take-shift" disabled={!canWork} onClick={() => { dispatch({ type: 'work' }); close(); }}><BriefcaseBusiness size={15} />{canWork ? 'Take the shift' : 'Not enough energy'}</PrimaryButton>
  </Modal>;
}

function MegaMart({ state, dispatch, close }: { state: GameState; dispatch: React.Dispatch<Action>; close: () => void }) {
  const products = [
    { item: 'DSLR camera', price: 480, icon: Camera, note: '+15% upload quality' },
    { item: 'ring light', price: 85, icon: Sparkles, note: '+8% thumbnail click' },
    { item: 'PC + editor team', price: 1200, icon: Laptop, note: 'unlock serious edits' },
    { item: 'wardrobe rack', price: 260, icon: Shirt, note: '+10 fame on appearances' },
  ];
  return <Modal title="MegaMart" eyebrow="equipment / debt disguised as progress" onClose={close}>
    <div className="mb-5 flex items-center justify-between border-b border-white/[.08] pb-4"><span className="text-xs uppercase tracking-[.14em] text-slate-500">Available now</span><span className="font-mono text-sm font-bold text-[#d8aa56]">{money(state.cash)}</span></div>
    <div className="space-y-2">
      {products.map(({ item, price, icon: Icon, note }) => { const owned = state.inventory.includes(item); return <div key={item} className="flex items-center gap-3 rounded-xl border border-white/[.07] bg-white/[.025] p-3">
        <div className="grid size-10 shrink-0 place-items-center rounded-lg bg-[#202b39] text-[#d8aa56]"><Icon size={18} /></div>
        <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-[#eee5d7]">{item}</p><p className="text-[11px] text-slate-500">{note}</p></div>
        <button data-testid={`button-buy-${item.replaceAll(' ', '-')}`} disabled={owned || state.cash < price} onClick={() => dispatch({ type: 'buy', item, price })} className="rounded-lg border border-[#d8aa56]/35 px-3 py-2 font-mono text-[11px] font-bold text-[#d8aa56] transition hover:bg-[#d8aa56]/10 disabled:opacity-35">{owned ? 'Owned' : money(price)}</button>
      </div>; })}
    </div>
    <p className="mt-5 text-[11px] leading-relaxed text-slate-500">The first camera is an expense. The second camera is a tax write-off.</p>
  </Modal>;
}

function CreatorApp({ platform, state, dispatch, close }: { platform: 'viewtube' | 'reeltok'; state: GameState; dispatch: React.Dispatch<Action>; close: () => void }) {
  const [topic, setTopic] = useState('A broke actor’s first week');
  const [effort, setEffort] = useState('scrappy');
  const [edit, setEdit] = useState('phone');
  const [thumbnail, setThumbnail] = useState('honest');
  const [result, setResult] = useState<{ views: number; followers: number; comments: string[]; label: string } | null>(null);
  const isTube = platform === 'viewtube';
  const followers = state.followers[platform];
  const trend = topic.toLowerCase().includes('rent') || topic.toLowerCase().includes('broke');
  const upload = () => {
    const base = isTube ? 86 : 114;
    const quality = effort === 'all-in' ? 1.55 : effort === 'careful' ? 1.2 : .82;
    const editBoost = edit === 'team' ? 1.45 : edit === 'desktop' ? 1.22 : 1;
    const clickBoost = thumbnail === 'clickbait' ? 1.34 : thumbnail === 'polished' ? 1.12 : .93;
    const views = Math.max(24, Math.round(base * quality * editBoost * clickBoost * (trend ? 1.8 : 1) + state.skill.social * 3));
    const gained = Math.max(1, Math.floor(views / (isTube ? 18 : 24)));
    const label = views > 250 ? 'The algorithm blinked. You were there.' : 'A small signal in a very large room.';
    setResult({ views, followers: gained, label, comments: views > 250 ? ['This is weirdly honest.', 'The lighting is doing a lot.', 'Part two or this is a crime.'] : ['first', 'you good?', 'algorithm did you dirty'] });
    dispatch({ type: 'upload', platform, followers: gained, fame: views > 250 ? 2 : 0, cost: isTube ? 0 : 0, label });
  };
  if (!state.accounts[platform]) return <Modal title={isTube ? 'ViewTube' : 'ReelTok'} eyebrow="creator account / zero is a number" onClose={close}>
    <div className="mb-6 overflow-hidden rounded-2xl border border-white/[.08] bg-[#0d121a] p-5">
      <div className="mb-5 flex items-center gap-3"><div className={`grid size-11 place-items-center rounded-xl ${isTube ? 'bg-[#b84251]' : 'bg-[#7953a8]'}`}><MonitorPlay size={22} /></div><div><p className="font-semibold text-[#eee5d7]">{isTube ? 'ViewTube' : 'ReelTok'} creator account</p><p className="font-mono text-[10px] uppercase tracking-[.13em] text-slate-500">Handle available: @marrow18</p></div></div>
      <p className="text-sm leading-relaxed text-slate-400">No brand deals. No audience. No safety net. Just a cracked phone and something to say.</p>
    </div>
    <PrimaryButton testId={`button-create-${platform}`} onClick={() => dispatch({ type: 'account', platform })}><Plus size={15} />Create free account</PrimaryButton>
  </Modal>;
  return <Modal title={isTube ? 'ViewTube' : 'ReelTok'} eyebrow="creator studio / publish or disappear" onClose={close}>
    {result ? <div className="animate-rise">
      <div className="mb-5 rounded-2xl border border-[#d8aa56]/30 bg-gradient-to-br from-[#d8aa56]/15 to-transparent p-5"><div className="mb-3 flex items-center justify-between"><span className="font-mono text-[10px] uppercase tracking-[.18em] text-[#d8aa56]">Upload report</span><Check size={18} className="text-[#8ac8a3]" /></div><div className="flex items-end gap-3"><span className="font-serif text-5xl text-[#f4ead8]">{result.views}</span><span className="pb-2 text-xs uppercase tracking-[.13em] text-slate-400">views</span></div><p className="mt-2 text-sm italic text-[#d8aa56]">“{result.label}”</p></div>
      <div className="mb-5 space-y-2">{result.comments.map((comment) => <div key={comment} className="flex items-center gap-2 rounded-lg bg-white/[.035] px-3 py-2 text-xs text-slate-400"><CircleUserRound size={14} className="text-slate-600" /><span className="font-mono text-[#b6a68f]">@somebody</span>{comment}</div>)}</div>
      <PrimaryButton testId="button-close-result" onClick={close}>Back to home</PrimaryButton>
    </div> : <>
      <div className="mb-5 flex items-end justify-between border-b border-white/[.08] pb-4"><div><p className="font-mono text-2xl text-[#f1e7d7]">{followers.toLocaleString()}</p><p className="text-[10px] uppercase tracking-[.15em] text-slate-500">{isTube ? 'subscribers' : 'followers'} · monetization at 1,000</p></div><div className="text-right"><p className="font-mono text-sm text-[#d8aa56]">{trend ? 'TREND +80%' : 'NO TREND'}</p><p className="text-[10px] uppercase tracking-[.15em] text-slate-500">topic pulse</p></div></div>
      <label className="mb-4 block"><span className="mb-2 block text-[10px] font-bold uppercase tracking-[.15em] text-slate-500">Topic</span><input data-testid={`input-topic-${platform}`} value={topic} onChange={(e) => setTopic(e.target.value)} className="w-full rounded-xl border border-white/10 bg-white/[.045] px-3 py-3 text-sm text-[#f0e8da] outline-none focus:border-[#d8aa56]" /></label>
      <div className="mb-4 grid gap-3 sm:grid-cols-3"><Choice label="Effort" value={effort} setValue={setEffort} options={[['scrappy', 'Scrappy'], ['careful', 'Careful'], ['all-in', 'All-in']]} /><Choice label="Editing" value={edit} setValue={setEdit} options={[['phone', 'Phone'], ['desktop', 'Desktop'], ['team', 'Editor team']]} /><Choice label="Thumbnail" value={thumbnail} setValue={setThumbnail} options={[['honest', 'Honest'], ['polished', 'Polished'], ['clickbait', 'Clickbait']]} /></div>
      <div className="mb-5 rounded-xl border border-white/[.07] bg-[#0d121a] p-3 text-xs leading-relaxed text-slate-500"><TrendingUp size={14} className="mb-1 text-[#d8aa56]" />Trend boost: people are watching “broke” stories. They may stop watching when the story gets better.</div>
      <PrimaryButton testId={`button-upload-${platform}`} onClick={upload}><Upload size={15} />Publish first video</PrimaryButton>
    </>}
  </Modal>;
}

function Choice({ label, value, setValue, options }: { label: string; value: string; setValue: (v: string) => void; options: string[][] }) {
  return <div><span className="mb-2 block text-[10px] font-bold uppercase tracking-[.15em] text-slate-500">{label}</span><select data-testid={`select-${label.toLowerCase()}`} value={value} onChange={(e) => setValue(e.target.value)} className="w-full rounded-xl border border-white/10 bg-[#1a222e] px-2 py-3 text-xs text-[#eee4d2] outline-none"><>{options.map(([v, n]) => <option key={v} value={v}>{n}</option>)}</></select></div>;
}

function UtilityModal({ app, state, dispatch, close }: { app: AppConfig; state: GameState; dispatch: React.Dispatch<Action>; close: () => void }) {
  const previews: Record<string, { title: string; copy: string; icon: LucideIcon }> = {
    rent: { title: 'Rent & Bills', copy: 'Your lease is month-to-month in everything but language. $220 will leave every seventh day.', icon: FileText },
    social: { title: 'Social', copy: 'You have 0 industry contacts. That is not a flaw yet. It is a countdown.', icon: Users },
    messages: { title: 'Messages', copy: 'No one is waiting for you here. Change that before you need something.', icon: MessageCircle },
    analytics: { title: 'Analytics', copy: 'Analytics unlock after your first upload. Numbers are a kind of weather report.', icon: TrendingUp },
    fund: { title: 'Creator Fund', copy: 'Monetization unlocks at 1,000 subscribers. The platform keeps 55% before you arrive.', icon: CircleDollarSign },
  };
  const special = previews[app.id];
  return <Modal title={special?.title || app.name} eyebrow={app.kind === 'locked' ? 'locked / read the gate' : 'preview / coming into focus'} onClose={close}>
    <div className="grid place-items-center rounded-2xl border border-white/[.08] bg-[#0d121a] px-6 py-10 text-center">
      {app.kind === 'locked' ? <LockKeyhole size={34} className="mb-4 text-[#d8aa56]" /> : special ? <special.icon size={34} className="mb-4 text-[#d8aa56]" /> : <app.icon size={34} className="mb-4 text-slate-500" />}
      <h3 className="mb-2 font-serif text-2xl text-[#f0e6d7]">{app.kind === 'locked' ? 'Not yet, kid.' : special?.title || app.name}</h3>
      <p className="max-w-sm text-sm leading-relaxed text-slate-500">{app.id === 'starcast' ? `StarCast requires acting skill above 20. You have ${state.skill.acting}. Train in Skill Lab, then come back with a face the room cannot ignore.` : special?.copy || `${app.subtitle}. This part of the city is still being wired. For now, the tap is a promise.`}</p>
      {app.id === 'starcast' && <div className="mt-5 w-full max-w-xs"><div className="mb-2 flex justify-between text-[10px] uppercase tracking-widest text-slate-500"><span>acting skill</span><span>{state.skill.acting} / 21</span></div><Progress value={(state.skill.acting / 21) * 100} color="#d8aa56" /></div>}
      <button data-testid="button-dismiss-preview" onClick={close} className="mt-6 flex items-center gap-2 text-xs font-bold uppercase tracking-[.14em] text-[#d8aa56] hover:text-[#f0c56f]">Understood <ArrowUpRight size={14} /></button>
    </div>
  </Modal>;
}

function SkillModal({ state, dispatch, close }: { state: GameState; dispatch: React.Dispatch<Action>; close: () => void }) {
  const skills = [{ id: 'acting' as const, label: 'Acting', icon: Film, color: '#d8aa56' }, { id: 'editing' as const, label: 'Editing', icon: Pencil, color: '#8dc3bd' }, { id: 'social' as const, label: 'Social instinct', icon: Users, color: '#c77b88' }];
  return <Modal title="Skill Lab" eyebrow="invest in the version of you that gets picked" onClose={close}>
    <div className="space-y-3">{skills.map(({ id, label, icon: Icon, color }) => <div key={id} className="rounded-xl border border-white/[.08] p-4"><div className="mb-3 flex items-center gap-3"><Icon size={17} style={{ color }} /><div className="flex-1"><div className="flex justify-between"><span className="text-sm font-semibold text-[#eee5d7]">{label}</span><span className="font-mono text-xs text-slate-400">{state.skill[id]}</span></div><div className="mt-2"><Progress value={state.skill[id] * 2.5} color={color} /></div></div><button data-testid={`button-train-${id}`} onClick={() => dispatch({ type: 'train', skill: id, cost: 14 })} disabled={state.energy < 14} className="ml-2 rounded-lg border border-white/10 px-2.5 py-2 text-[10px] font-bold uppercase tracking-widest text-[#d8aa56] disabled:opacity-30">Train</button></div><p className="text-[11px] text-slate-500">14 energy · +5 skill</p></div>)}</div>
  </Modal>;
}

function StarLife() {
  const [state, dispatch] = useReducer(gameReducer, initialState);
  const [activeApp, setActiveApp] = useState<AppId | null>(null);
  const [notice, setNotice] = useState('');
  const [showAdvance, setShowAdvance] = useState(false);
  const app = useMemo(() => apps.find((item) => item.id === activeApp), [activeApp]);

  const launch = (id: AppId) => {
    setActiveApp(id);
    if (id === 'wallet') setNotice('Cash is real. Potential is not yet liquid.');
  };
  const advance = () => {
    dispatch({ type: 'advance' });
    setShowAdvance(true);
    window.setTimeout(() => setShowAdvance(false), 700);
  };
  const close = () => setActiveApp(null);
  const week = Math.ceil(state.day / 7);

  return <main className="grain min-h-[100dvh] bg-[#090d13] text-[#f2ead9]">
    <div className="mx-auto flex min-h-[100dvh] w-full max-w-[1240px] flex-col border-x border-white/[.04] bg-[radial-gradient(circle_at_78%_4%,rgba(166,106,72,.13),transparent_28%),linear-gradient(140deg,#0b1018_0%,#0b0f16_55%,#121018_100%)]">
      <header className="sticky top-0 z-20 border-b border-white/[.08] bg-[#0b1018]/92 backdrop-blur-xl">
        <div className="flex h-14 items-center justify-between px-4 sm:px-7">
          <div className="flex items-center gap-3"><div className="grid size-8 place-items-center rounded-[10px] border border-[#d8aa56]/35 bg-[#d8aa56]/10"><Star size={15} className="text-[#d8aa56]" /></div><div><div className="font-mono text-[10px] font-bold uppercase tracking-[.28em] text-[#d8aa56]">StarOS</div><div className="font-serif text-base leading-none text-[#f3e9d8]">Star Life <span className="font-sans text-[9px] uppercase tracking-widest text-slate-600">v0.1</span></div></div></div>
          <div className="hidden items-center gap-3 text-[10px] uppercase tracking-[.18em] text-slate-500 sm:flex"><Wifi size={13} className="text-[#8dbeb5]" /> Los Angeles / offline mode <Signal size={13} className="text-[#8dbeb5]" /></div>
          <div className="flex items-center gap-2 text-slate-500"><BatteryMedium size={17} /><span className="font-mono text-[10px]">08:42</span></div>
        </div>
        <div className="grid grid-cols-5 border-t border-white/[.05] bg-[#0b1018]/80 py-2">
          <Stat icon={CalendarDays} label={`day ${state.day}`} value={`W${week}`} color="#d8aa56" />
          <Stat icon={CircleDollarSign} label="balance" value={money(state.cash)} color="#8dc3bd" />
          <Stat icon={Star} label="fame" value={state.fame} color="#d8aa56" />
          <Stat icon={Zap} label="energy" value={state.energy} color="#e5b95d" suffix="%" />
          <Stat icon={HeartPulse} label="health" value={state.health} color="#c77b88" suffix="%" />
        </div>
      </header>

      <section className="px-4 pb-4 pt-5 sm:px-7 sm:pt-7">
        <div className="mb-5 flex items-end justify-between gap-4"><div><div className="mb-1 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.2em] text-slate-500"><span className="inline-block size-1.5 rounded-full bg-[#c77b88]" />personal dashboard</div><h1 className="font-serif text-[2.7rem] leading-[.9] tracking-tight text-[#f3e9d8] sm:text-5xl">Make it out.</h1><p className="mt-2 max-w-md text-xs leading-relaxed text-slate-500 sm:text-sm">The city wants your rent, your attention, and the version of you that never looks tired.</p></div><button data-testid="button-advance-day" onClick={advance} className={`group flex min-h-11 shrink-0 items-center gap-2 rounded-xl border border-[#d8aa56]/50 bg-[#d8aa56]/10 px-3 text-[10px] font-bold uppercase tracking-[.13em] text-[#e4b965] transition hover:bg-[#d8aa56]/20 active:scale-[.97] ${showAdvance ? 'animate-stat' : ''}`}><Clock3 size={15} />Advance day<ChevronRight size={14} className="transition group-hover:translate-x-0.5" /></button></div>
        <div className="grid gap-3 sm:grid-cols-[1.4fr_1fr]">
          <div className="rounded-2xl border border-white/[.08] bg-[#121923]/80 p-4 shadow-[0_20px_60px_rgba(0,0,0,.18)] sm:p-5"><div className="mb-4 flex items-start justify-between"><div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-slate-500">daily condition</p><p data-testid="text-hunger-status" className="mt-1 text-sm font-semibold text-[#efe4d2]">{state.hunger < 30 ? 'Your body is filing a complaint.' : state.energy < 30 ? 'Battery red. Pride still green.' : 'You are still in the game.'}</p></div><Activity size={18} className="text-[#c77b88]" /></div><div className="grid grid-cols-2 gap-4"><div><div className="mb-1.5 flex justify-between text-[10px] uppercase tracking-widest text-slate-500"><span>hunger</span><span className="font-mono">{state.hunger}%</span></div><Progress value={state.hunger} color="#c77b88" /></div><div><div className="mb-1.5 flex justify-between text-[10px] uppercase tracking-widest text-slate-500"><span>energy</span><span className="font-mono">{state.energy}%</span></div><Progress value={state.energy} color="#d8aa56" /></div></div></div>
          <div className="flex items-center justify-between rounded-2xl border border-[#8dbeb5]/15 bg-[#8dbeb5]/[.05] p-4 sm:p-5"><div><p className="mb-1 font-mono text-[10px] uppercase tracking-[.17em] text-[#8dbeb5]">last transmission</p><p data-testid="text-last-action" className="max-w-[230px] text-xs leading-relaxed text-slate-400">{state.lastAction}</p></div><WifiOff size={19} className="shrink-0 text-[#8dbeb5]/70" /></div>
        </div>
      </section>

      <section className="flex-1 px-4 pb-24 sm:px-7 sm:pb-10"><div className="mb-4 flex items-center justify-between"><div><h2 className="font-serif text-2xl text-[#f0e6d7]">Your phone</h2><p className="text-[10px] uppercase tracking-[.16em] text-slate-600">tap into the life you cannot afford</p></div><div className="font-mono text-[10px] text-slate-600">{apps.length} apps installed</div></div>
        <div className="grid grid-cols-3 gap-2.5 min-[420px]:grid-cols-4 sm:grid-cols-6 lg:grid-cols-8">
          {apps.map((item, index) => { const Icon = item.icon; const locked = item.id === 'starcast' && state.skill.acting <= 20; return <button key={item.id} data-testid={`app-${item.id}`} onClick={() => launch(item.id)} className="group animate-rise relative min-h-[106px] overflow-hidden rounded-2xl border border-white/[.07] bg-[#131a24]/80 p-3 text-left transition duration-200 hover:-translate-y-0.5 hover:border-white/20 hover:bg-[#192331] active:scale-[.97]" style={{ animationDelay: `${Math.min(index, 12) * 24}ms` }}>
            <div className={`mb-3 grid size-9 place-items-center rounded-[11px] border border-white/10 ${item.tint === 'gold' ? 'bg-[#d8aa56]/15 text-[#d8aa56]' : item.tint === 'coral' ? 'bg-[#bd5262]/15 text-[#d27682]' : item.tint === 'blue' ? 'bg-[#598eb5]/15 text-[#8bb9d7]' : item.tint === 'violet' ? 'bg-[#8669ac]/15 text-[#b69bd7]' : item.tint === 'mint' ? 'bg-[#5b9f96]/15 text-[#8ccbc0]' : item.tint === 'pink' ? 'bg-[#a55f7c]/15 text-[#d18ba5]' : item.tint === 'green' ? 'bg-[#5b9e77]/15 text-[#8fc59f]' : item.tint === 'orange' ? 'bg-[#b87551]/15 text-[#d7a180]' : 'bg-white/[.06] text-slate-400'}`}><Icon size={18} strokeWidth={1.7} /></div>
            <div className="truncate text-[11px] font-bold text-[#e8dece]">{item.name}</div><div className="mt-0.5 truncate text-[9px] text-slate-600">{item.subtitle}</div>{locked && <LockKeyhole size={11} className="absolute right-3 top-3 text-[#d8aa56]" />}
          </button>; })}
        </div>
      </section>

      <footer className="fixed bottom-0 left-0 right-0 z-20 border-t border-white/[.08] bg-[#0b1018]/95 px-4 py-2.5 backdrop-blur-xl sm:static sm:border-0 sm:bg-transparent sm:px-7 sm:pb-7">
        <div className="mx-auto flex max-w-[1240px] items-center justify-between gap-3"><div className="flex items-center gap-2 text-[10px] text-slate-600"><Phone size={13} />Cracked phone · shared apartment</div><button data-testid="button-eat" onClick={() => dispatch({ type: 'eat' })} disabled={state.cash < 8} className="flex min-h-9 items-center gap-2 rounded-lg border border-[#c77b88]/35 bg-[#c77b88]/10 px-3 text-[10px] font-bold uppercase tracking-[.13em] text-[#d88d9a] transition hover:bg-[#c77b88]/20 disabled:opacity-30"><Utensils size={13} />Eat · $8</button></div>
      </footer>
    </div>
    {activeApp === 'jobs' && <JobBoard state={state} dispatch={dispatch} close={close} />}
    {activeApp === 'mart' && <MegaMart state={state} dispatch={dispatch} close={close} />}
    {(activeApp === 'viewtube' || activeApp === 'reeltok') && <CreatorApp platform={activeApp} state={state} dispatch={dispatch} close={close} />}
    {activeApp === 'skills' && <SkillModal state={state} dispatch={dispatch} close={close} />}
    {app && !['jobs', 'mart', 'viewtube', 'reeltok', 'skills'].includes(app.id) && <UtilityModal app={app} state={state} dispatch={dispatch} close={close} />}
    {notice && <button data-testid="button-dismiss-notice" onClick={() => setNotice('')} className="fixed bottom-20 left-1/2 z-30 -translate-x-1/2 rounded-full border border-white/10 bg-[#1b2531] px-4 py-2 text-xs text-slate-300 shadow-xl sm:bottom-8">{notice}</button>}
  </main>;
}

export default StarLife;